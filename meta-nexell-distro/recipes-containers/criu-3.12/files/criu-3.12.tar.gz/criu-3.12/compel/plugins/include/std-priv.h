#ifndef __COMPEL_PLUGIN_STD_PRIV_H__
#define __COMPEL_PLUGIN_STD_PRIV_H__

extern int std_ctl_sock(void);

#endif /* __COMPEL_PLUGIN_STD_PRIV_H__ */
