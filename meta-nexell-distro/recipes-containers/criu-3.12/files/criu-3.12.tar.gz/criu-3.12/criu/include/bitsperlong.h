#ifndef __CR_INC_BITSPERLONG_H__
#define __CR_INC_BITSPERLONG_H__
#include "common/bitsperlong.h"
#endif
