#ifndef __CR_INC_PAGE_H__
#define __CR_INC_PAGE_H__
#include "common/page.h"
#endif
