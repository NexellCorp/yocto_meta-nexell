#include "log.h"
#include "common/xmalloc.h"
