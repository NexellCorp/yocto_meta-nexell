#ifndef DEFINES_H
#define DEFINES_H

enum Menu {
	Menu_Init,
    Menu_Select,
    Menu_Connection,
    Menu_Advanced
};

#endif // DEFINES_H
