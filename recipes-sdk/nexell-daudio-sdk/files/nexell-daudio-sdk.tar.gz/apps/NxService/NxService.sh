#!/bin/sh

# Add services to run below
/usr/bin/NxDAudioManager &
/usr/bin/NxBTServiceR &
