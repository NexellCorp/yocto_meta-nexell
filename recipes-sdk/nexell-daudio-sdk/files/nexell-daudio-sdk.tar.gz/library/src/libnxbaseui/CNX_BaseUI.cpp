#include "CNX_BaseUI.h"

CNX_BaseUI::CNX_BaseUI()
{
}
