#ifndef CNX_BASEUI_H
#define CNX_BASEUI_H

#include "CNX_BaseUI_global.h"

class CNXBASEUISHARED_EXPORT CNX_BaseUI
{

public:
	CNX_BaseUI();
};

#endif // CNX_BASEUI_H
